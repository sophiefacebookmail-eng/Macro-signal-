"""Indicator calculations and confluence scoring."""
import numpy as np


def ema(values, period: int) -> float:
    v = np.asarray(values, dtype=float)
    if len(v) < period:
        return float("nan")
    alpha = 2.0 / (period + 1)
    result = float(v[:period].mean())
    for value in v[period:]:
        result = float(value) * alpha + result * (1 - alpha)
    return result


def rsi(values, period: int = 14) -> float:
    v = np.asarray(values, dtype=float)
    if len(v) < period + 1:
        return float("nan")
    changes = np.diff(v)
    gains = np.where(changes > 0, changes, 0.0)
    losses = np.where(changes < 0, -changes, 0.0)
    avg_gain = float(gains[:period].mean())
    avg_loss = float(losses[:period].mean())
    for i in range(period, len(changes)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    if avg_loss == 0:
        return 100.0
    return 100.0 - 100.0 / (1 + avg_gain / avg_loss)


def atr(ohlcv, period: int = 14) -> float:
    if len(ohlcv) < period + 1:
        return float("nan")
    highs = np.asarray([c[2] for c in ohlcv], dtype=float)
    lows = np.asarray([c[3] for c in ohlcv], dtype=float)
    closes = np.asarray([c[4] for c in ohlcv], dtype=float)
    tr = np.maximum(highs[1:] - lows[1:],
                    np.maximum(np.abs(highs[1:] - closes[:-1]),
                               np.abs(lows[1:] - closes[:-1])))
    value = float(tr[:period].mean())
    for item in tr[period:]:
        value = (value * (period - 1) + item) / period
    return value


def volume_ok(ohlcv, lookback=20, multiplier=1.0) -> bool:
    if len(ohlcv) < lookback + 1:
        return False
    previous = [c[5] for c in ohlcv[-(lookback + 1):-1]]
    average = sum(previous) / len(previous) if previous else 0
    return average > 0 and ohlcv[-1][5] >= average * multiplier


def confluence_signal(ohlcv, cfg):
    """Return (action, score, metadata). The final, potentially open candle is excluded."""
    settings = cfg["strategy"]
    # Exclude the currently forming candle to avoid intrabar/repainting alerts.
    bars = ohlcv[:-1]
    required = max(settings["ema_slow"] + 10, settings["rsi_period"] + 1,
                   settings["atr_period"] + 1, 22)
    if len(bars) < required:
        return "NEUTRAL", 0, {"reason": "insufficient_closed_candles"}

    closes = [c[4] for c in bars]
    fast = ema(closes, settings["ema_fast"])
    slow = ema(closes, settings["ema_slow"])
    momentum = rsi(closes, settings["rsi_period"])
    atr_value = atr(bars, settings["atr_period"])
    last = closes[-1]
    atr_pct = (atr_value / last) * 100 if last else float("nan")
    if not all(np.isfinite(x) for x in (fast, slow, momentum, atr_pct)):
        return "NEUTRAL", 0, {"reason": "invalid_indicator"}

    bullish = last > fast > slow
    bearish = last < fast < slow
    score, reasons = 0, []
    if bullish or bearish:
        score += 40
        reasons.append("Trend alignment")
    if 40 <= momentum <= settings["rsi_long_max"] or settings["rsi_short_min"] <= momentum <= 60:
        score += 20
        reasons.append("RSI zone")
    if atr_pct >= settings["atr_min_pct"]:
        score += 20
        reasons.append("ATR volatility")
    if volume_ok(bars, 20, settings["volume_multiplier"]):
        score += 20
        reasons.append("Volume confirmation")

    action = "NEUTRAL"
    if bullish and momentum < settings["rsi_long_max"] and score >= settings["min_confluence"]:
        action = "LONG"
    elif bearish and momentum > settings["rsi_short_min"] and score >= settings["min_confluence"]:
        action = "SHORT"

    stop_pct = 2.0
    tp_pcts = (2.5, 5.0, 8.0)
    if action == "LONG":
        stop = last * (1 - stop_pct / 100)
        targets = [last * (1 + p / 100) for p in tp_pcts]
    elif action == "SHORT":
        stop = last * (1 + stop_pct / 100)
        targets = [last * (1 - p / 100) for p in tp_pcts]
    else:
        stop, targets = None, []

    return action, score, {
        "price": last, "ema50": fast, "ema200": slow, "rsi": momentum,
        "atr_pct": atr_pct, "reasons": reasons, "stop": stop,
        "targets": targets, "candle_ts": bars[-1][0]
    }
