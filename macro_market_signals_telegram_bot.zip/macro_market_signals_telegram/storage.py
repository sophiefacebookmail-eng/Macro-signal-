"""Small SQLite store for Telegram subscribers and duplicate-alert protection."""
import sqlite3
import time


class Store:
    def __init__(self, path):
        self.path = path
        with self.connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS subscribers (
                chat_id INTEGER PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1,
                created_at INTEGER NOT NULL)""")
            db.execute("""CREATE TABLE IF NOT EXISTS sent_signals (
                market TEXT NOT NULL, symbol TEXT NOT NULL, candle_ts INTEGER NOT NULL,
                action TEXT NOT NULL, sent_at INTEGER NOT NULL,
                PRIMARY KEY(market, symbol, candle_ts, action))""")

    def connect(self):
        db = sqlite3.connect(self.path)
        db.row_factory = sqlite3.Row
        return db

    def subscribe(self, chat_id):
        with self.connect() as db:
            db.execute("INSERT INTO subscribers(chat_id, enabled, created_at) VALUES(?,1,?) "
                       "ON CONFLICT(chat_id) DO UPDATE SET enabled=1",
                       (chat_id, int(time.time())))

    def unsubscribe(self, chat_id):
        with self.connect() as db:
            db.execute("UPDATE subscribers SET enabled=0 WHERE chat_id=?", (chat_id,))

    def subscribers(self):
        with self.connect() as db:
            return [r["chat_id"] for r in db.execute(
                "SELECT chat_id FROM subscribers WHERE enabled=1").fetchall()]

    def already_sent(self, market, symbol, candle_ts, action):
        with self.connect() as db:
            return db.execute(
                "SELECT 1 FROM sent_signals WHERE market=? AND symbol=? AND candle_ts=? AND action=?",
                (market, symbol, int(candle_ts), action)).fetchone() is not None

    def mark_sent(self, market, symbol, candle_ts, action):
        with self.connect() as db:
            db.execute("INSERT OR IGNORE INTO sent_signals VALUES(?,?,?,?,?)",
                       (market, symbol, int(candle_ts), action, int(time.time())))
