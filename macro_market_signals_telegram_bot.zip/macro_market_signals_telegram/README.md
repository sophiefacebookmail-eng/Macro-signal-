# Macro Market Signals — Telegram Bot

Signals-only Telegram bot for XAU/USD (gold), GBP/USD, other major FX pairs, and selected
crypto-USD markets such as BTC/USD. Market candles come from Twelve Data.

**No Binance integration, no broker connection, no exchange credentials, and no order execution.**

## Setup
1. Create a bot with Telegram `@BotFather` using `/newbot`.
2. Install Python 3.10+ and dependencies:

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
cp .env.example .env
```

3. Put your Telegram bot token and Twelve Data API key in `.env`.
4. Start it with `python telegram_bot.py`, then send `/start` to your bot.

Twelve Data coverage, intraday timeframes and request limits depend on your subscription.
Confirm that your plan supports every symbol you enable.

## Commands
`/start` subscribe · `/scan` scan now · `/signals` show setups · `/status` check service
· `/markets` list symbols · `/unsubscribe` stop alerts · `/help` command guide

## Default markets
XAU/USD, GBP/USD, EUR/USD, USD/JPY, AUD/USD, USD/CAD, NZD/USD, BTC/USD, ETH/USD, SOL/USD.
Edit `config.yaml` to add/remove instruments, change the 15-minute timeframe, scan interval,
or confluence threshold.

The bot evaluates closed candles and stores sent alert keys in SQLite to reduce duplicates.
Signals and stop/target references are heuristic research outputs, not proven profitable
setups, personalised advice, or broker orders. Paper-test before relying on alerts.
