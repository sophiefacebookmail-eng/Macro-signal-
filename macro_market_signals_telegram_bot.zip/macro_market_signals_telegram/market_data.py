"""Read-only market data via Twelve Data. No exchange connection or order methods."""
from datetime import datetime, timezone
import aiohttp

class MarketData:
    def __init__(self, twelve_key=""):
        self.twelve_key = twelve_key
        self.session = None

    async def ohlcv(self, symbol, interval="15min", outputsize=300):
        if not self.twelve_key:
            raise RuntimeError("TWELVEDATA_API_KEY is not configured")
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession()
        params = {"symbol": symbol, "interval": interval, "outputsize": outputsize,
                  "apikey": self.twelve_key, "format": "JSON"}
        async with self.session.get("https://api.twelvedata.com/time_series",
                                    params=params, timeout=25) as response:
            data = await response.json()
        if data.get("status") == "error" or "values" not in data:
            raise RuntimeError(data.get("message", "Twelve Data returned no values"))
        rows = []
        for item in reversed(data["values"]):
            stamp = datetime.strptime(item["datetime"], "%Y-%m-%d %H:%M:%S")
            stamp = stamp.replace(tzinfo=timezone.utc).timestamp()
            rows.append([int(stamp), float(item["open"]), float(item["high"]),
                         float(item["low"]), float(item["close"]),
                         float(item.get("volume") or 0)])
        return rows

    async def close(self):
        if self.session and not self.session.closed:
            await self.session.close()
