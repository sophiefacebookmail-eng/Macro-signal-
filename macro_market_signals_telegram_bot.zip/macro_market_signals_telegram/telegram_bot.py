"""Telegram signals-only bot for gold, FX and selected crypto-USD symbols."""
import asyncio
import logging
import os
from pathlib import Path

import yaml
from dotenv import load_dotenv
from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import Application, CommandHandler, ContextTypes

from indicators import confluence_signal
from market_data import MarketData
from storage import Store

BASE = Path(__file__).resolve().parent
load_dotenv(BASE / ".env")
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"),
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("macro_market_signals")

with open(BASE / "config.yaml", encoding="utf-8") as stream:
    CFG = yaml.safe_load(stream)

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
STORE = Store(str(BASE / CFG["state"]["db_path"]))
DATA = MarketData(twelve_key=os.getenv("TWELVEDATA_API_KEY", "").strip())
SCAN_LOCK = asyncio.Lock()
APP = None


def fmt_price(value):
    if value is None:
        return "—"
    return f"{value:,.5f}" if abs(value) < 100 else f"{value:,.2f}"


def signal_message(symbol, action, score, meta):
    emoji = "🟢" if action == "LONG" else "🔴"
    lines = [
        f"{emoji} <b>{symbol} — {action}</b>",
        f"Confluence: <b>{score}/100</b>",
        f"Timeframe: {CFG['strategy']['timeframe']}",
        f"Reference price: <code>{fmt_price(meta.get('price'))}</code>",
        f"EMA50: {fmt_price(meta.get('ema50'))} | EMA200: {fmt_price(meta.get('ema200'))}",
        f"RSI: {meta.get('rsi', 0):.1f} | ATR: {meta.get('atr_pct', 0):.2f}%",
        f"Illustrative stop reference: <code>{fmt_price(meta.get('stop'))}</code>",
    ]
    for i, target in enumerate(meta.get("targets", []), 1):
        lines.append(f"Illustrative TP{i}: <code>{fmt_price(target)}</code>")
    lines += ["Filters: " + (", ".join(meta.get("reasons", [])) or "—"), "",
              "⚠️ Research alert only, not financial advice or an instruction to trade. "
              "Levels are illustrative and do not account for spread, fees or slippage."]
    return "\n".join(lines)


async def send_to_subscribers(message):
    for chat_id in STORE.subscribers():
        try:
            await APP.bot.send_message(chat_id=chat_id, text=message,
                                       parse_mode=ParseMode.HTML)
        except Exception:
            log.exception("Could not send alert to chat_id=%s", chat_id)


async def scan_markets():
    results = []
    async with SCAN_LOCK:
        settings = CFG["strategy"]
        for symbol in CFG["markets"]:
            try:
                bars = await DATA.ohlcv(symbol, settings["timeframe"],
                                        settings["candle_limit"])
                action, score, meta = confluence_signal(bars, CFG)
                results.append((symbol, action, score, meta))
            except Exception as exc:
                log.warning("Scan failed for %s: %s", symbol, exc)
    alerts = []
    for symbol, action, score, meta in results:
        if action == "NEUTRAL":
            continue
        candle_ts = meta.get("candle_ts", 0)
        if STORE.already_sent("MARKET", symbol, candle_ts, action):
            continue
        STORE.mark_sent("MARKET", symbol, candle_ts, action)
        alerts.append(signal_message(symbol, action, score, meta))
    return results, alerts


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    STORE.subscribe(update.effective_chat.id)
    await update.message.reply_text(
        "Welcome to Macro Market Signals. You are subscribed to research alerts.\n\n"
        "/scan — scan markets now\n/signals — show current qualifying setups\n"
        "/status — service status\n/markets — supported instruments\n"
        "/unsubscribe — stop alerts\n/help — command guide\n\n"
        "Signals only: this bot cannot execute trades."
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "/start — subscribe\n/scan — run a fresh scan\n"
        "/signals — show current setups\n/status — feed and subscription status\n"
        "/markets — supported instruments\n/unsubscribe — stop alerts"
    )


async def unsubscribe(update: Update, context: ContextTypes.DEFAULT_TYPE):
    STORE.unsubscribe(update.effective_chat.id)
    await update.message.reply_text("Unsubscribed. Use /start to subscribe again.")


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    subscribed = update.effective_chat.id in STORE.subscribers()
    ready = bool(os.getenv("TWELVEDATA_API_KEY", "").strip())
    await update.message.reply_text(
        "Macro Market Signals: RUNNING\n"
        f"Telegram alerts: {'ON' if subscribed else 'OFF'}\n"
        f"Twelve Data feed: {'CONFIGURED' if ready else 'NOT CONFIGURED'}\n"
        f"Timeframe: {CFG['strategy']['timeframe']}\n"
        "Execution: DISABLED — signals only"
    )


async def markets(update: Update, context: ContextTypes.DEFAULT_TYPE):
    listing = "\n".join("• " + symbol for symbol in CFG["markets"])
    await update.message.reply_text(
        "SUPPORTED MARKETS\n" + listing +
        "\n\nData availability depends on your Twelve Data subscription."
    )


async def run_scan(update):
    await update.message.reply_text("Scanning configured markets…")
    results, _ = await scan_markets()
    actionable = [r for r in results if r[1] != "NEUTRAL"]
    if not actionable:
        await update.message.reply_text(
            "Scan complete: no setups met the configured confluence threshold.")
        return
    for symbol, action, score, meta in actionable:
        await update.message.reply_text(signal_message(symbol, action, score, meta),
                                        parse_mode=ParseMode.HTML)


async def scan_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await run_scan(update)


async def signals_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await run_scan(update)


async def scheduled_scan(context: ContextTypes.DEFAULT_TYPE):
    try:
        _, alerts = await scan_markets()
        for alert in alerts:
            await send_to_subscribers(alert)
    except Exception:
        log.exception("Scheduled scan failed")


async def post_init(application: Application):
    application.job_queue.run_repeating(
        scheduled_scan, interval=int(CFG["telegram"]["scan_interval_sec"]), first=15)


async def post_shutdown(application: Application):
    await DATA.close()


def main():
    global APP
    if not TOKEN:
        raise SystemExit("Missing TELEGRAM_BOT_TOKEN. Set it in your .env file.")
    APP = (Application.builder().token(TOKEN).post_init(post_init)
           .post_shutdown(post_shutdown).build())
    APP.add_handler(CommandHandler("start", start))
    APP.add_handler(CommandHandler("help", help_command))
    APP.add_handler(CommandHandler("unsubscribe", unsubscribe))
    APP.add_handler(CommandHandler("status", status))
    APP.add_handler(CommandHandler("markets", markets))
    APP.add_handler(CommandHandler("scan", scan_command))
    APP.add_handler(CommandHandler("signals", signals_command))
    APP.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
